function generateHeader() {
    return new Promise(function (resolve, reject) {
        loadHTML("/header/header.html").then(function (res) {
            const node = new DOMParser().parseFromString(res, 'text/html').body.firstElementChild;
            document.body.prepend(node);
            loadScript("/header/js/header.js")
                .then(data => {
                    loadJSHeader();
                    resolve();
                })
                .catch(err => {
                    console.error(err);
                    reject();
                });
        });
    });
}

function generateFooter() {
    return new Promise(function (resolve, reject) {
        loadHTML("/footer/footer.html").then(function (res) {
            const node = new DOMParser().parseFromString(res, 'text/html').body.firstElementChild;
            document.body.append(node);
            resolve();
        });
    });
}

function loadHTML(path) {
    return new Promise(function (resolve, reject) {
        var xobj = new XMLHttpRequest();
        xobj.overrideMimeType("text/html");
        xobj.open('GET', path, true);
        xobj.onreadystatechange = function () {
            if (xobj.readyState == 4 && xobj.status == "200") {
                resolve(xobj.responseText);
            }
        };
        xobj.send(null);
    });
}

const loadScript = (FILE_URL, async = true, type = "text/javascript") => {
    return new Promise((resolve, reject) => {
        try {
            const scriptEle = document.createElement("script");
            scriptEle.type = type;
            scriptEle.async = async;
            scriptEle.src = FILE_URL;

            scriptEle.addEventListener("load", (ev) => {
                resolve({ status: true });
            });

            scriptEle.addEventListener("error", (ev) => {
                reject({
                    status: false,
                    message: `Failed to load the script ＄{FILE_URL}`
                });
            });

            document.body.appendChild(scriptEle);
        } catch (error) {
            reject(error);
        }
    });
};

function scrollSmooth(elementName) {
    var pos = 0;

    if (elementName.charAt(0) != "#" && elementName != "") {
        window.location.href = elementName;
        return;
    }

    if (elementName != 0) {
        pos = offset(elementName).top;
    }

    window.scroll({
        top: pos,
        left: 0,
        behavior: 'smooth'
    });
}

function scrollSmoothCoords(pos) {
    window.scroll({
        top: pos,
        left: 0,
        behavior: 'smooth'
    });
}

function offset(el) {
    el = document.querySelector(el);
    var rect = el.getBoundingClientRect(),
        scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,
        scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    return { top: rect.top + scrollTop, left: rect.left + scrollLeft, bottom: rect.bottom + scrollTop, right: rect.right + scrollLeft }
}

function offsetObject(el) {
    var rect = el.getBoundingClientRect(),
        scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,
        scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    return { top: rect.top + scrollTop, left: rect.left + scrollLeft, bottom: rect.bottom + scrollTop, right: rect.right + scrollLeft }
}

window.addEventListener('DOMContentLoaded', function () {
    Promise.all([generateHeader(), generateFooter()]).then(function (values) {
        document.querySelectorAll('a').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                scrollSmooth(this.getAttribute('href'));
            });
        });
        scrollSmooth("#top");
    });
    menuOffset = offset("menu").top;
    contentMarginTop = offset(".content").top - offset("#menu").top;
    menuHeight = offset("menu").bottom - offset("menu").top;
});

window.addEventListener('resize', function (event) {
    menuOffset = offset("#menu").top;
    contentMarginTop = offset(".content").top - offset("#menu").top;
});

var menuOffset, fixed, contentMarginTop;

window.addEventListener("scroll", (event) => {
    if (window.pageYOffset > menuOffset) {
        //Menu fixed
        menu = document.querySelector("#menu-fixed");
        content = document.querySelector(".content");

        menu.style.display = "flex";
        menu.style.position = "fixed";
        content.style.marginTop = contentMarginTop + "px";

        tiles = Array.from(document.querySelectorAll("#menu-fixed > li")).reverse();
        elements = Array.from(document.querySelectorAll(".content > section")).reverse();

        found = false;

        for (let i = 0; i < tiles.length; i++) {
            if (offsetObject(elements[i]).top - menuHeight < window.pageYOffset) {
                if (!found) {
                    tiles[i].querySelector("div > span").style.display = "initial";
                    found = true;
                } else {
                    tiles[i].querySelector("div > span").style.display = "none";
                }
            } else {
                tiles[i].querySelector("div > span").style.display = "none";
            }
        }

        if (!found) {
            tiles[tiles.length - 1].querySelector("div > span").style.display = "initial";
        }
    } else {
        //Menu not fixed
        document.querySelector("#menu-fixed").style.display = "";
        document.querySelector("#menu-fixed").style.position = "";
        document.querySelector(".content").style.marginTop = "";

        document.querySelectorAll("#menu-fixed > li").forEach(element => {
            element.querySelector("div > span").style.display = "none";
        });
    }

    if (window.pageYOffset == 0) {
        document.getElementById("arrow").style.transform = "translate(-50%, -50%) rotate(180deg)"
        document.getElementById("btt").setAttribute('onclick', 'scrollSmoothCoords(document.body.offsetHeight)');
    } else {
        document.getElementById("arrow").style.transform = "translate(-50%, -50%)"
        document.getElementById("btt").setAttribute('onclick', 'scrollSmoothCoords(0)');
    }
});