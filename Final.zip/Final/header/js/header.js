function loadJSHeader(){
    document.getElementById("menu-open").addEventListener("click", open);
    document.getElementById("menu-close").addEventListener("click", close);

    const mediaQuery = window.matchMedia('(min-width: 951px)');

    mediaQuery.addListener(handleTabletChange);
    handleTabletChange(mediaQuery);
};

function handleTabletChange(e) {
    if (e.matches) {
        close();
    }
}

function open(){
    document.getElementById("menu-open").style.display = "none";
    document.getElementById("menu-close").style.display = "unset";
    document.getElementById("logo-desktop").style.display = "none";
    document.querySelector("header").style.flexDirection = "column";
    document.querySelector("header").style.alignItems = "unset";
    document.querySelector("header").style.backgroundColor = "#0864a9";
    document.querySelector(".logo").style.margin = 0;
    document.querySelector(".logo h1").style.display = "none";
    document.getElementById("logo-mobile").style.display = "unset";
    document.getElementById("logo-mobile").style.margin = "auto";
    document.querySelectorAll("nav h1").forEach(element => {
        element.style.display = "unset";
    });
}

function close(){
    document.getElementById("menu-open").style.display = "unset";
    document.getElementById("menu-close").style.display = "none";
    document.getElementById("logo-desktop").style.display = "";
    document.querySelector("header").style.flexDirection = "unset";
    document.querySelector("header").style.alignItems = "center";
    document.querySelector("header").style.backgroundColor = "";
    document.querySelector(".logo").style.margin = "";
    document.querySelector(".logo h1").style.display = "";
    document.getElementById("logo-mobile").style.display = "";
    document.getElementById("logo-mobile").style.margin = "";
    document.querySelectorAll("nav h1").forEach(element => {
        element.style.display = "";
    });
}