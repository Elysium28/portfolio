Fichiers :
- C/* :
    Algorithme de Matthew

    Exécution :
    - Le compiler à l'aide de cc puis l'exécuter

- Python/* :
    Algorithme de Camille

    Exécution :
    - Exécuter à l'aide de Python3 main.py

Vidéos de présentation :
- 100x100 : https://drive.google.com/file/d/13JEGT0yZ_GoQXhFD2PgCmaYOzDIpe_P8/view?usp=sharing
- 150x150 : https://drive.google.com/file/d/1oJy0aRWYLFX-D4Uypwl8LXuPDvwugwP2/view?usp=sharing