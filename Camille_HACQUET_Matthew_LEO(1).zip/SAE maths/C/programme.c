#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX 5  // défini la taille du tableau
#define CASE MAX*MAX  // défini le nombre de cases du tableau

typedef int tableau[MAX][MAX]; // le tableau qui représente le plateau du jeu
typedef int tab_chemin[CASE];  // le tableau qui contient les cases visité.

void init_tab(tableau tab);
void affiche_tab(tableau tab);
int nb_elements(tab_chemin tab);
void init_tab_chemin(tab_chemin tab);
bool compare_case(tab_chemin tab, int val);
void affiche_tab_chemin(tab_chemin tab);
bool trouve_chemin(tableau tab, tab_chemin list_case, int x, int y, bool rep);

void init_tab(tableau tab)
{ // initialise le plateau du jeu et attribue à chaque cases une valeur
    int i, j, k = 0;
    for (i = 0; i < MAX; i++)
    {
        for (j = 0; j < MAX; j++)
        {
            tab[i][j] = k;
            k++;
        }
    }
}

void affiche_tab(tableau tab)
{ // affiche le plateau de jeu avec les valeurs de chaque cases
    int i, j;
    for (i = 0; i < MAX; i++)
    {
        for (j = 0; j < MAX; j++)
        {
            printf("%d ", tab[i][j]);
        }
        printf("\n");
    }
}

int nb_elements(tab_chemin tab)
{ // compte le nombre de déplacement qu'a fait le cavalier
    int i, j = 0;
    for (i = 0; i < CASE; i++)
    {
        if (tab[i] != -1)
        {
            j++;
        }
        else
        {
            i = CASE;
        }
    }
    return j;
}

void init_tab_chemin(tab_chemin tab)
{ // initialise le tableau qui contient le chemin du cavalier
    int i;
    for (i = 0; i < CASE; i++)
    {
        tab[i] = -1;
    }
}

bool compare_case(tab_chemin tab, int val)
{ // compare si la case de destination du cavalier à déja été visité
    int i;
    bool resu = false;
    for (i = 0; i < CASE; i++)
    {
        if (tab[i] == val)
        {
            resu = true;
        }
        else if (tab[i] == -1)
        {
            i = CASE;
        }
    }
    return resu;
}

void affiche_tab_chemin(tab_chemin tab)
{ // affiche le parcours du cavalier
    int i;
    printf("[ ");
    for (i = 0; i < CASE; i++)
    {
        printf("%d ", tab[i]);
    }
    printf("]\n\n");
}

bool trouve_chemin(tableau tab, tab_chemin list_case, int x, int y, bool rep)
{
    // Cette fonction récursive permet de trouver une solution au problème du tour du cavalier
    int i = 0, l, c, nb_elem = nb_elements(list_case);
    bool meme_case;

    list_case[nb_elem] = tab[y][x];

    if (nb_elem == CASE - 1) // vérifie si toutes les cases ont été visitées
    {
        rep = true;
    }
    else
    {
        while (i < 9 && rep == false) // parcours les 8 possibilités de déplacement du cavalier
        {
            switch (i)
            {
            case 0:
                l = y - 2;
                c = x - 1;

                if (l >= 0 && l < MAX && c >= 0 && c < MAX)
                { // vérifie que la prochaine cases n'est pas en dehors du tableau
                    meme_case = compare_case(list_case, tab[l][c]);// vérifie que la prochaine case n'a pas été visitée
                    if (meme_case == false)
                    {
                        rep = trouve_chemin(tab, list_case, c, l, rep);
                    }
                }
                break;
            case 1:
                l = y - 2;
                c = x + 1;

                if (l >= 0 && l < MAX && c >= 0 && c < MAX)
                {// vérifie que la prochaine cases n'est pas en dehors du tableau
                    meme_case = compare_case(list_case, tab[l][c]);// vérifie que la prochaine case n'a pas été visitée
                    if (meme_case == false)
                    {
                        rep = trouve_chemin(tab, list_case, c, l, rep);
                    }
                }
                break;
            case 2:
                l = y - 1;
                c = x + 2;

                if (l >= 0 && l < MAX && c >= 0 && c < MAX)
                {// vérifie que la prochaine cases n'est pas en dehors du tableau
                    meme_case = compare_case(list_case, tab[l][c]);// vérifie que la prochaine case n'a pas été visitée
                    if (meme_case == false)
                    {
                        rep = trouve_chemin(tab, list_case, c, l, rep);
                    }
                }
                break;
            case 3:
                l = y + 1;
                c = x + 2;

                if (l >= 0 && l < MAX && c >= 0 && c < MAX)
                {// vérifie que la prochaine cases n'est pas en dehors du tableau
                    meme_case = compare_case(list_case, tab[l][c]);// vérifie que la prochaine case n'a pas été visitée
                    if (meme_case == false)
                    {
                        rep = trouve_chemin(tab, list_case, c, l, rep);
                    }
                }
                break;
            case 4:
                l = y + 2;
                c = x + 1;

                if (l >= 0 && l < MAX && c >= 0 && c < MAX)
                {// vérifie que la prochaine cases n'est pas en dehors du tableau
                    meme_case = compare_case(list_case, tab[l][c]);// vérifie que la prochaine case n'a pas été visitée
                    if (meme_case == false)
                    {
                        rep = trouve_chemin(tab, list_case, c, l, rep);
                    }
                }
                break;
            case 5:
                l = y + 2;
                c = x - 1;

                if (l >= 0 && l < MAX && c >= 0 && c < MAX)
                {// vérifie que la prochaine cases n'est pas en dehors du tableau
                    meme_case = compare_case(list_case, tab[l][c]);// vérifie que la prochaine case n'a pas été visitée
                    if (meme_case == false)
                    {
                        rep = trouve_chemin(tab, list_case, c, l, rep);
                    }
                }
                break;
            case 6:
                l = y + 1;
                c = x - 2;

                if (l >= 0 && l < MAX && c >= 0 && c < MAX)
                {// vérifie que la prochaine cases n'est pas en dehors du tableau
                    meme_case = compare_case(list_case, tab[l][c]);// vérifie que la prochaine case n'a pas été visitée
                    if (meme_case == false)
                    {
                        rep = trouve_chemin(tab, list_case, c, l, rep);
                    }
                }
                break;
            case 7:
                l = y - 1;
                c = x - 2;

                if (l >= 0 && l < MAX && c >= 0 && c < MAX)
                {// vérifie que la prochaine cases n'est pas en dehors du tableau
                    meme_case = compare_case(list_case, tab[l][c]);// vérifie que la prochaine case n'a pas été visitée
                    if (meme_case == false)
                    {
                        rep = trouve_chemin(tab, list_case, c, l, rep);
                    }
                }
                break;
            default: // si aucuns des coups ne débauche sur une solution on retourne un coup en arrière
                if (rep == false) 
                {
                    list_case[nb_elem] = -1;
                }
                break;
            }
            i++;
            
        }
    }
    return rep;
}
int main()
{
    tableau tab;
    tab_chemin list_case;

    int x = 2, y = 2; // initialise la position de départ
    bool resu = false;

    init_tab(tab);
    affiche_tab(tab);
    init_tab_chemin(list_case);

    resu = trouve_chemin(tab, list_case, x, y, resu);// cherche si il y a une solution

    if (resu == true)// si une solution est trouvée
    {
        printf("Le résultat est : \n");
        affiche_tab_chemin(list_case);
    }
    else// si il n'y a pas de solution
    {
        printf("impossible\n");
    }

    return EXIT_SUCCESS;
}