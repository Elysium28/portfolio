import tkinter as tk
from chess import Chess

master = tk.Tk()
board = Chess(master, 8, 80)
#usage : board = Chess(master, number_of_rows_and_columns, size_of_squares_in_pixels)

master.mainloop()