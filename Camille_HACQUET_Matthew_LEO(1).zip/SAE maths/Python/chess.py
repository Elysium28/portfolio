"""
This module defines the Chess class that allows users to interact with a chess board and find knight's tour solutions.

The Chess class provides a graphical user interface to interact with a chess board of a specified size.
It uses Warnsdorff's rule algorithm to find a knight's tour solution and displays the tour on the board.
"""

import sys
import tkinter as tk
import threading

sys.setrecursionlimit(100000)

MOVES = [(1, 2),(2, 1),(-1, -2),(-2, -1),(1, -2),(-2, 1),(-1, 2),(2, -1)]

class Chess:
    def __init__(self, master, size, box_size=80):
        """
        Initialize the Chess object.
        Args:
            master (tk.Tk): The tkinter parent widget.
            size (int): The number of squares per side of the chess board.
            box_size (int, optional): The size of each square in pixels. Defaults to 80.
        """
        self.master = master
        self.size = size
        self.box_size = box_size
        self.window_size = self.size*self.box_size
        self.board = tk.Canvas(self.master, width=self.window_size, height=self.window_size)
        self.solver_running = False
        self.settings()

    def settings(self):
        """
        Configure the chess board settings and initialize the board display.
        """
        self.draw_board()

        self.board.tag_bind("box", "<Button-1>", self.clicked)
        self.board.tag_bind("circle", "<Button-1>", self.clicked)
        self.board.tag_bind("line", "<Button-1>", self.clicked)

        self.board.pack()

        self.master.title("Jeu d'échecs")
        self.master.resizable(False, False)

    def draw_board(self):
        """
        Draw the chess board on the canvas.
        """
        colors = ["white", "gray"]
        for i in range(self.size):
            for j in range(self.size):
                color = colors[(i+j) % 2]
                x1 = j * self.box_size
                y1 = i * self.box_size
                x2 = x1 + self.box_size
                y2 = y1 + self.box_size
                self.board.create_rectangle(x1, y1, x2, y2, fill=color, tags="box")

    def clicked(self, event):
        """
        Handle click events on the canvas.

        Args:
            event (tk.Event): The event object containing information about the click.
        """
        if self.solver_running:
            return
    
        # Get the x and y coordinates of the click relative to the canvas
        x = event.x
        y = event.y

        # Calculate the indices of the box that was clicked
        i = y // self.box_size
        j = x // self.box_size

        self.clear()
        self.addCircle((i, j), None, "green")

        # Create a new thread for the solve function
        solve_thread = threading.Thread(target=self.solve, args=((i, j),))
        solve_thread.daemon = True
        solve_thread.start()  # Start the new thread

    def displayPossibilities(self, coords):
        """
        Display possible knight moves from the given coordinates.

        Args:
            coords (tuple): A tuple containing the row and column indices of the current position.
        """
        availableBoxes = []

        # Get availabled boxes
        for move in MOVES:
            i, j = coords
            di, dj = move
            new_position = (i + di, j + dj)
            if 0 <= new_position[0] < self.size and 0 <= new_position[1] < self.size:
                availableBoxes.append((new_position[0], new_position[1]))
        
        print(availableBoxes)
        for box in availableBoxes:
            self.addCircle(box, None, "orange")
    
    def solve(self, coords):
        """
        Solve the knight's tour problem starting from the given coordinates.

        Args:
            coords (tuple): A tuple containing the row and column indices of the starting position.
        """
        self.solver_running = True

        # Create a 2D array to keep track of the visited squares
        visited = [[False for _ in range(self.size)] for _ in range(self.size)]

        i, j = coords

        # Call the recursive helper function to find a solution
        if self.solve_helper_warnsdorff((i, j), visited, 1):
            print("Solution found!")
        else:
            print("No solution found.")
            self.clear()
            self.addCircle((i, j), None, "red")
        
        self.solver_running = False

    def get_moves_count(self, coords, visited):
        """
        Get the count of valid moves from the given coordinates.

        Args:
            coords (tuple): A tuple containing the row and column indices of the current position.
            visited (list of list of bool): A 2D array indicating whether each square has been visited.

        Returns:
            int: The count of valid moves from the given coordinates.
        """
        count = 0
        i, j = coords
        for move in MOVES:
            new_i, new_j = i + move[0], j + move[1]
            if 0 <= new_i < self.size and 0 <= new_j < self.size and not visited[new_i][new_j]:
                count += 1
        return count

    def solve_helper_warnsdorff(self, coords, visited, count):
        """
        Recursive helper function for solving the knight's tour problem using Warnsdorff's rule.

        Args:
            coords (tuple): A tuple containing the row and column indices of the current position.
            visited (list of list of bool): A 2D array indicating whether each square has been visited.
            count (int): The count of visited squares.

        Returns:
            bool: True if a solution is found, False otherwise.
        """
        # Mark the current square as visited
        i, j = coords
        visited[i][j] = True

        # Base case: if all squares have been visited, we've found a solution
        if count == self.size ** 2:
            self.addCircle((i, j), None, "red")
            return True

        # Get a list of valid moves from the current square, sorted by the number of valid moves from the next square
        next_moves = []
        for move in MOVES:
            new_i, new_j = i + move[0], j + move[1]
            if 0 <= new_i < self.size and 0 <= new_j < self.size and not visited[new_i][new_j]:
                next_moves.append((new_i, new_j, self.get_moves_count((new_i, new_j), visited)))

        next_moves.sort(key=lambda x: x[2])

        # Try all possible moves from the current square
        for new_i, new_j, _ in next_moves:
            # Add a line to show the move we're trying
            self.addLine((i, j), (new_i, new_j), 2, "red")

            # Recursively try to solve the puzzle starting from the new position
            if self.solve_helper_warnsdorff((new_i, new_j), visited, count + 1):
                # Add a circle to show that we've visited this square
                self.addCircle((i, j))
                return True

            # If we didn't find a solution from the new position, remove the line and try the next move
            self.removeElement(f"line_{i}_{j}_{new_i}_{new_j}")

        # If we've tried all possible moves and none of them led to a solution, backtrack
        visited[i][j] = False
        self.addCircle((i, j))
        return False
        
    def addCircle(self, coords, r=None, color="black"):
        """
        Add a circle to the specified square on the board.

        Args:
            coords (tuple): A tuple containing the row and column indices of the target square.
            r (int, optional): The radius of the circle in pixels. Defaults to None.
            color (str, optional): The color of the circle. Defaults to "black".
        """
        i, j = coords

        # Calculate the center of the box
        cx = j * self.box_size + self.box_size // 2
        cy = i * self.box_size + self.box_size // 2

        #Check if out of range
        if not (0 <= i < self.size) or not (0 <= j < self.size):
            #print(f"The circle to add at ({i}, {j}) is out of range")
            return

        # Check if a circle already exists in the box
        tag = f"circle_{i}_{j}"
        overlapping_items = self.board.find_withtag(tag)
        if overlapping_items:
            #print(f"Already a circle at (x={cx}, y={cy}) in the box ({i}, {j})")
            return

        # Draw the circle
        if r == None:
            r = self.box_size // 4
        self.board.create_oval(cx - r, cy - r, cx + r, cy + r, fill=color, tags=[tag, "circle"], outline="")
    
    def addLine(self, coords_1, coords_2, width=None, color="red"):
        """
        Add a line between the centers of two specified squares on the board.

        Args:
            coords_1 (tuple): A tuple containing the row and column indices of the first square.
            coords_2 (tuple): A tuple containing the row and column indices of the second square.
            width (int, optional): The width of the line in pixels. Defaults to None.
            color (str, optional): The color of the line. Defaults to "red".
        """
        i1, j1 = coords_1
        i2, j2 = coords_2

        # Calculate the centers of the boxes
        x1 = j1 * self.box_size + self.box_size // 2
        y1 = i1 * self.box_size + self.box_size // 2
        x2 = j2 * self.box_size + self.box_size // 2
        y2 = i2 * self.box_size + self.box_size // 2

        #Check if out of range
        if not (0 <= i1 < self.size) or not (0 <= j1 < self.size) or not (0 <= i2 < self.size) or not (0 <= j2 < self.size):
            #print(f"The line to add between ({i1}, {j1}) and ({i2}, {j2}) is out of range")
            return

        # Check if a line between the two boxes already exists
        tag1 = f"line_{i1}_{j1}_{i2}_{j2}"
        tag2 = f"line_{i2}_{j2}_{i1}_{j1}"
        overlapping_items1 = self.board.find_withtag(tag1)
        overlapping_items2 = self.board.find_withtag(tag2)
        if overlapping_items1 or overlapping_items2:
            #print(f"Already a line between ({i1}, {j1}) and ({i2}, {j2})")
            return

        # Draw the line
        if width == None:
            width = 3
        self.board.create_line(x1, y1, x2, y2, width=width, fill=color, tags=[tag1, "line"])
    
    def removeElement(self, tag):
        """
        Remove an element with the specified tag from the canvas.

        Args:
            tag (str): The tag of the element to be removed.
        """
        self.board.delete(tag)
    
    def clear(self):
        """
        Clear all circles and lines from the canvas.
        """
        self.board.delete("circle")
        self.board.delete("line")