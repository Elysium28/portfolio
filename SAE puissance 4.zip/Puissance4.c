/*Programme final du puissance 4.

Matthew LEO 1C1 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

const char CROIX ='X';
const char ROND ='O';
const char VIDE =' ';
const int LIGNE = 6;
const int COLONNE = 7;



typedef char tableau[6][7];

void affichepuissance4();
int check_grille_pleine(tableau grille);
void fairejouer(tableau grille, char nom[20], char symbole,int *position, int *ligne);
int choisir_colonne(char nom[20], tableau grille, char symbole, int position);
int trouver_ligne(int position, tableau grille);
void affichePalteau(tableau grille, int position, char symbole);
void init_grille(tableau grille);
bool check_horizontal(tableau grille, int ligne, int colonne);
bool check_vertical(tableau grille, int ligne, int colonne);
bool check_diagonal(tableau grille, int ligne, int colonne);
bool estVainqueur(tableau grille, int ligne, int colonne);
void fin_de_partie(char nom[20]);


//procédure qui affiche simplement le mot "puissance 4" en grosses lettres
void affichepuissance4(){
    printf("██████╗ ██╗   ██╗██╗███████╗███████╗ █████╗ ███╗   ██╗ ██████╗███████╗    ██╗  ██╗\n");
    printf("██╔══██╗██║   ██║██║██╔════╝██╔════╝██╔══██╗████╗  ██║██╔════╝██╔════╝    ██║  ██║\n");
    printf("██████╔╝██║   ██║██║███████╗███████╗███████║██╔██╗ ██║██║     █████╗      ███████║\n");
    printf("██╔═══╝ ██║   ██║██║╚════██║╚════██║██╔══██║██║╚██╗██║██║     ██╔══╝      ╚════██║\n");
    printf("██║     ╚██████╔╝██║███████║███████║██║  ██║██║ ╚████║╚██████╗███████╗         ██║\n");
    printf("╚═╝      ╚═════╝ ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝╚══════╝         ╚═╝\n");
}

/* cette fonction vérifie à chaque tours si la grille est pleine ou non en regardant si au moins une case la plus haute ligne
contient un caractère espace. Elle revoie 0 si la grille n'est pas pleine et 1 sinon*/
int check_grille_pleine(tableau grille){
    int rempli=0;
    if ((grille[0][0]!=' ')&&(grille[0][1]!=' ')&&(grille[0][2]!=' ')&&(grille[0][3]!=' ')&&(grille[0][4]!=' ')&&(grille[0][5]!=' ')&&(grille[0][6]!=' ')){
        rempli=1;
    }
    return rempli;
}


/*procédure qui permet de placer le pion dans la grille à l'emplacement souhaiter */
void fairejouer(tableau grille, char nom[20], char symbole, int *position, int *ligne){
    int colonne_dernier_pion= *position;
    do{
        *position = choisir_colonne(nom, grille, symbole, colonne_dernier_pion);
        *ligne=trouver_ligne(*position, grille);
    }while (*ligne == -1);
    grille[*ligne][*position] = symbole;
    printf("\n\n\n\n");
}   

/*fonction qui demande le numéro de la colonne de la grille dans laquelle l'utilisateur souhaite placer son pions,
ce numéro est ensuite implémenter de -1 afin de correspondre à la segmentation du tableau.*/
int choisir_colonne(char nom[20], tableau grille, char symbole, int position){
    char direction;
    do{
            printf("<== Q      D ==>\n\n");
            printf("Espace pour valider\n");
            printf("Dans quelle colonne veux-tu placer ton pion %s ?\n",nom);
            scanf("%c", &direction);
            if (((direction=='d')||(direction=='D'))&&(position<6)){
                position++;
                affichePalteau(grille, position, symbole);
            }
            else if (((direction=='q')||(direction=='Q'))&&(position>0)){
                position--;
                affichePalteau(grille, position, symbole);
            }
            else if(direction!=' '){
                affichePalteau(grille, position, symbole);
            }
            
        }while (direction!=' ');
        return position;
}

// fonction qui vas permettre de trouver la plus basse ligne disponible de la grille à partir du numéro de la colonne en paramètre d'entrée, et de vérifier si la colonne choisie par le joueur est pleine
int trouver_ligne(int position, tableau grille){
    int retour=0, ligne;
    char actuel;
    for (ligne=5; ligne>-1; ligne--){
            actuel = grille[ligne][position]; //case du tableau dans laquelle ont se trouve
            if (actuel==' '){
                retour=ligne;
                ligne=-1;   
            }
            else if ((actuel==CROIX)||(actuel==ROND)){
                retour ++; // compteur, si il arrive à 6 cela signifie que la colonne est pleine
            }
        }
        if (retour==6){
            retour=-1;
        }
        return retour;
}


// procédure qui permet d'afficher la grille du jeu tel quelle évolue dans la partie ainsi que le pion qui se déplace.
void affichePalteau(tableau grille, int position, char symbole){
    int ligne, colonne, esp_position;
    system("clear");
    affichepuissance4();
    printf(" ");
    //permet de savoir où afficher le pion au dessus de la grille.
    for (esp_position = 0; esp_position < position; esp_position++)
    {
        printf("  ");
    }
    printf("%c", symbole);
    printf("\n");
    for(ligne=0; ligne<6; ligne++){
        printf("|");
        for(colonne=0; colonne<7; colonne++){
            printf("%c|", grille[ligne][colonne]);
        }
        printf("\n");
    }
    printf("|=============|");
    printf("\n\n");
}

// procédure qui vas placer un espace dans chaque emplacement de la grille
void init_grille(tableau grille){
    int i, j;
    for (i = 0; i < LIGNE ; i++)
    {
        for ( j = 0; j < COLONNE; j++)
        {
            grille[i][j]= VIDE;
        }
    }
}

// fonction qui vas vérifier si il y a des pions semblable adjacent horizontalement a celui qui vient d'être placé. 
bool check_horizontal(tableau grille, int ligne, int colonne){
    bool gagner=false;
    int i, verif=1;
    char symbole= grille[ligne][colonne];
    if (colonne!=6){
        for (i = colonne+1; i < COLONNE; i++)
        {
            if (grille[ligne][i]==symbole){
                verif++;
            }
            else{
                i=COLONNE;
            }
        }
    }
    if ((verif<4)&&(colonne!=0))
    {
        for (i = colonne-1; i >-1; i--)
        {
            if (grille[ligne][i]==symbole){
                verif++;
            }
            else{
                i=-1;
            }
            
        }
    }
    if(verif >= 4){
        gagner=true;
    }
    return gagner;
}

// fonction qui vas vérifier si il y a 3 pions semblables au pion qui vient d'être placer en dessous de celui-ci. 
bool check_vertical(tableau grille, int ligne, int colonne){
    bool gagner=false;
    int i, verif=1;
    char symbole= grille[ligne][colonne];
    if(ligne<=2){
        for (i = ligne+1; i < LIGNE; i++)
        {
            if (grille[i][colonne]==symbole)
            {
                verif++;
            }
            else{
                i=LIGNE;
            }
        }
    }
    if(verif >= 4){
        gagner=true;
    }
    return gagner;
}


// fonction qui vas vérifier si il y a des pions semblable a celui qui vient d'être placé adjacent à ce dernier en diagonale. 
bool check_diagonal(tableau grille, int ligne, int colonne){
    char symbole= grille[ligne][colonne];
    bool gagner=false;
    int i=1, verif=1;
    while(grille[ligne-i][colonne+i]==symbole){
        verif++;
        i++;
    }
    i=1;
    while (grille[ligne+i][colonne-i]==symbole)
    {
        verif++;
        i++;
    }
    if (verif>=4)
    {
        gagner=true;
    }
    else{
        i=1;
        verif=1;
        while(grille[ligne-i][colonne-i]==symbole){
        verif++;
        i++;
        }
        i=1;
        while (grille[ligne+i][colonne+i]==symbole)
        {
            verif++;
            i++;
        }
        if (verif>=4)
        {
        gagner=true;
        }
    }
    return gagner;  
    
}




// fonction qui vas appeler les 3 fonctions de vérification de victoire et qui renvoie true si la partie a été gagnée par le dernier joueur à avoir placer son pion.
bool estVainqueur(tableau grille, int ligne, int colonne){
    bool gagne;
    gagne=check_horizontal(grille, ligne, colonne);
    if(gagne==false){
        gagne=check_vertical(grille, ligne, colonne);
        if(gagne==false){
            gagne=check_diagonal(grille, ligne, colonne);
        }
    }
    return gagne;
}

// procédure qui affiche le message de fin de partie en fonction du résultat de celle-ci.
void fin_de_partie(char nom[20]){
    if (strcmp(nom," ")!=0)
    {
        printf("Félicitations %s tu as gagné!\n\n", nom);
    }
    else{
        printf("Egalité, félicitations aux deux joueurs!\n\n");
    }
    
}



// programme principale qui vas permettre de prendre les noms des 2 joueur et de les faire jouer alternativement. 
int main(){
    system("clear");
    char nom_win[20]=" ", nomj1[20],nomj2[20], recommencer[20]="oui";
    int ligne,colonne, position;
    bool vainqueur; 
    int g_plein;
    tableau grille;
    affichepuissance4();
    printf("Entrez le nom du joueur qui utilisera les pions O :     ");
    scanf("%s", nomj1);
    printf("Entrez le nom du joueur qui utilisera les pions X :     ");
    scanf("%s", nomj2);

    while((strcmp(recommencer,"non")!=0)&&(strcmp(recommencer,"NON")!=0)){
        position=3;
        colonne=3;
        ligne=0;
        g_plein=0;
        vainqueur=false;
        init_grille(grille);
        affichePalteau(grille, position, ROND);
        g_plein=check_grille_pleine(grille);
        while ((vainqueur == false)&&(g_plein==0))
        {
            fairejouer(grille, nomj1, ROND, &colonne,&ligne);
            g_plein=check_grille_pleine(grille);
            affichePalteau(grille, colonne, CROIX);
            vainqueur= estVainqueur(grille, ligne, colonne);
            if (vainqueur==true){
                strcpy(nom_win,nomj1);
            }
            else if (g_plein==0){
                fairejouer(grille, nomj2, CROIX,&colonne, &ligne);
                affichePalteau(grille, colonne, ROND);
                vainqueur= estVainqueur(grille, ligne, colonne);
                if (vainqueur==true){
                strcpy(nom_win, nomj2);
                }
            }
            g_plein=check_grille_pleine(grille);
        }
        fin_de_partie(nom_win);
        do{
            printf("\nSouhaitez-vous recommencer une partie (oui ou non)?       ");
            scanf("%s", recommencer);
            if ((strcmp(recommencer,"oui")!=0)&&(strcmp(recommencer,"OUI")!=0)&&(strcmp(recommencer,"non")!=0)&&(strcmp(recommencer,"NON")!=0)){
                printf("erreur de saisie.");
            }
        }while ((strcmp(recommencer,"oui")!=0)&&(strcmp(recommencer,"OUI")!=0)&&(strcmp(recommencer,"non")!=0)&&(strcmp(recommencer,"NON")!=0));
        if (((strcmp(recommencer,"non")==0)||(strcmp(recommencer,"NON")==0)))
        {
            printf("Merci d'avoir joué, au revoir!\n");
        }
        
    }
    return EXIT_SUCCESS;
}


