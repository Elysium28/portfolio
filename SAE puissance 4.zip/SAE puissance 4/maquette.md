# Puissance 4


## Présentation :
### Cette application est un jeu de puissance 4:
- Il se joue uniquement avec 2 joueurs.
- Chaque joueur choisit un type de pions, soit `X` soit `O`.
- Le but du jeu est de parvenir à aligner 4 de ses pions avant son adversaire. Il peut les aligner horizontalement, verticalement ou diagonalement.
        

        Horizontalement :

         1 2 3 4 5 6 7
        | | | | | | | |
        | | | | | | | |
        | | | | | | | |
        | | | | | | | |
        | | | | |O| | |
        |X|X|X|X|O|O| |
        |=============|


        Verticalement :

         1 2 3 4 5 6 7
        | | | | | | | |
        | | | | | | | |
        | | |X| | | | |
        | | |X| | | | |
        | | |X| |O| | |
        | | |X| |O|O| |
        |=============|

        

        Diagonalement :

         1 2 3 4 5 6 7
        | | | | | | | |
        | | | | | | | |
        | | | | | |X| |
        | | | | |X|O| |
        | | | |X|O|X| |
        | | |X|O|X|O| |
        |=============|


        Dans les 3 cas ci-dessus, c'est le joueur qui possède les pions X qui gagne.

- Lorsqu'un joueur sélectionne le numéro de la colonne dans laquelle il souhaite placer sont pion, ce pion se positionne dans la case la plus basse disponible.

        Exemple:

                 1 2 3 4 5 6 7
                | | | | | | | |
                | | | | | | | |
                | | |X| | | | |      =  Cette situation est impossible. X
                | | | | | | | |
                | | |O| | | | |
                | | |X| | | | |
                |=============|

                

                 1 2 3 4 5 6 7
                | | | | | | | |
                | | | | | | | |
                | | | | | | | |      =  Ceci est la bonne situation. V
                | | |X| | | | |
                | | |O| | | | |
                | | |X| | | | |
                |=============|

## Déroulement de la Partie :
- Pour démarrer le jeu il suffit d'entrer la commande `./puissance4` dans le terminal.
- Le jeu démarrera alors en affichant cet écran :
```
██████╗ ██╗   ██╗██╗███████╗███████╗ █████╗ ███╗   ██╗ ██████╗███████╗    ██╗  ██╗
██╔══██╗██║   ██║██║██╔════╝██╔════╝██╔══██╗████╗  ██║██╔════╝██╔════╝    ██║  ██║
██████╔╝██║   ██║██║███████╗███████╗███████║██╔██╗ ██║██║     █████╗      ███████║
██╔═══╝ ██║   ██║██║╚════██║╚════██║██╔══██║██║╚██╗██║██║     ██╔══╝      ╚════██║
██║     ╚██████╔╝██║███████║███████║██║  ██║██║ ╚████║╚██████╗███████╗         ██║
╚═╝      ╚═════╝ ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝╚══════╝         ╚═╝


Entrez le nom du joueur qui utilisera les pions O :
```
L'un des deux joueur doit à présent entrer son nom, puis ce sera au tour du deuxième joueur.

- La partie peut alors commencer. La grille du jeu va s'afficher et il sera demandé au premier joueur d'entrer `le numéro de la colonne` dans laquelle il souhaite placer son pion.

```
██████╗ ██╗   ██╗██╗███████╗███████╗ █████╗ ███╗   ██╗ ██████╗███████╗    ██╗  ██╗
██╔══██╗██║   ██║██║██╔════╝██╔════╝██╔══██╗████╗  ██║██╔════╝██╔════╝    ██║  ██║
██████╔╝██║   ██║██║███████╗███████╗███████║██╔██╗ ██║██║     █████╗      ███████║
██╔═══╝ ██║   ██║██║╚════██║╚════██║██╔══██║██║╚██╗██║██║     ██╔══╝      ╚════██║
██║     ╚██████╔╝██║███████║███████║██║  ██║██║ ╚████║╚██████╗███████╗         ██║
╚═╝      ╚═════╝ ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝╚══════╝         ╚═╝


Entrez le nom du joueur qui jouera les pions O :  [réponse joueur1]

Entrez le nom du joueur qui jouera les pions X :  [réponse joueur2]

La partie peut commencer!

     1 2 3 4 5 6 7
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    |=============|

    Dans quelle colonne veux-tu placer ton pion [nom du joueur1] ?
```
- Si les joueurs veulent arrêter la partie avant la fin du jeu il leur suffit d'entrer `-1` à la place du numéro de sélectrion d'une colonne.

- Si le joueur entre autre chose que `-1 1 2 3 4 5 6 7`, alors le jeu reposera la question autant de fois que nécéssaire.

- Une fois la réponse du joueur1 entrée, une nouvelle grille s'affichera avec en plus le pion du joueur1 visible à l'emplacement indiqué. Ce sera ensuite le tour du joueur2, et ainsi de suite...


```
██████╗ ██╗   ██╗██╗███████╗███████╗ █████╗ ███╗   ██╗ ██████╗███████╗    ██╗  ██╗
██╔══██╗██║   ██║██║██╔════╝██╔════╝██╔══██╗████╗  ██║██╔════╝██╔════╝    ██║  ██║
██████╔╝██║   ██║██║███████╗███████╗███████║██╔██╗ ██║██║     █████╗      ███████║
██╔═══╝ ██║   ██║██║╚════██║╚════██║██╔══██║██║╚██╗██║██║     ██╔══╝      ╚════██║
██║     ╚██████╔╝██║███████║███████║██║  ██║██║ ╚████║╚██████╗███████╗         ██║
╚═╝      ╚═════╝ ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝╚══════╝         ╚═╝


Entrez le nom du joueur qui jouera les pions O :  [réponse joueur1]

Entrez le nom du joueur qui jouera les pions X :  [réponse joueur2]

La partie peut commencer!

     1 2 3 4 5 6 7
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    |=============|

    Dans quelle colonne veux-tu placer ton pion [nom du joueur1] ?  3

     1 2 3 4 5 6 7
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | |O| | | | |
    |=============|

    Dans quelle colonne veux-tu placer ton pion [nom du joueur2] ?  4

     1 2 3 4 5 6 7
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | |O|X| | | |
    |=============|

    Dans quelle colonne veux-tu placer ton pion [nom du joueur1] ?  2

     1 2 3 4 5 6 7
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | |O|O|X| | | |
    |=============|

    Dans quelle colonne veux-tu placer ton pion [nom du joueur2] ?  3

     1 2 3 4 5 6 7
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | | |X| | | | |
    | |O|O|X| | | |
    |=============|

    Dans quelle colonne veux-tu placer ton pion [nom du joueur1] ?
```
- Cette situation se répètera jusqu'à ce que l'un des joueurs parvienne à aligner 4 de ses pions (comme dans les exemples donnés plus haut) ou que la grille soit complète sans qu'aucun des joueurs n'ai pu aligner 4 pions, exemple :

         1 2 3 4 5 6 7
        |O|X|X|O|X|X|O|
        |X|O|O|X|X|X|O|
        |O|X|X|O|O|O|X|   = Dans cette situation il y a égalité car la grille est 
        |X|O|O|O|X|O|O|     complète et aucun des deux joueurs n'a aligné 4 de ses
        |O|X|X|X|O|X|X|     pions.
        |X|X|O|O|O|X|O|
        |=============|



- En cas de victoire d'un des deux joueurs, ou d'égalité, la partie prend fin. Le jeu affiche alors le nom du gagnant et demande aux joueurs si ils souhaitent refaire une partie.

    - Si les joueurs répondent `oui`, alors la partie repart de zéro en conservant toutefois le nom des 2 joueurs.

    - Si les joueurs répondent `non`, alors le jeu prendra fin, et il faudra entrer de nouveau la commande `./puissance4` pour rejouer.

    - Si les joueurs entrent autre chose que `oui` ou `non` alors le jeu reposera la question autant de fois que nécéssaire.

```
     1 2 3 4 5 6 7
    | | | | | | | |
    | | | | | | | |
    | | | | | | | |
    | |O|X| | | | |
    | |O|X|X| | | |
    | |O|O|X| | | |
    |=============|

Dans quelle colonne veux-tu placer ton pion [nom du joueur1] ?  2

     1 2 3 4 5 6 7
    | | | | | | | |
    | | | | | | | |
    | |O| | | | | |
    | |O|X| | | | |
    | |O|X|X| | | |
    | |O|O|X| | | |
    |=============|

    Félicitations [nom du joueur 1] tu as gagné!

    Souhaitez-vous recommencer une partie (oui ou non)?  non

    Merci d'avoir joué, au revoir!
```


