#!/usr/bin/php
<?php
// initialisation des dates
date_default_timezone_set('Europe/Paris');
$date = date('d-m-y H:i');
$date_trimestre = date('m-Y');

$conf=file("regions.conf"); // déclaration de la variable qui contient le fichier conf

$directory="workdirs/texte-workdir/textes/{$argv[1]}/";
$tabdir=scandir($directory,SCANDIR_SORT_ASCENDING); // scan du répertoire

foreach ($tabdir as $fichier) {  // parcours du répertoire et initialisation des variable contenant les fichier
    if ($fichier=="tableau.dat") {
        $data=file_get_contents($directory.$fichier);
        $file_tableau = json_decode($data, true); 
    }
    elseif ($fichier=="comm.dat") {
        $data=file_get_contents($directory.$fichier);
        $file_comm = json_decode($data, true);
    }
    elseif ($fichier=="texte.dat") {
        $data=file_get_contents($directory.$fichier);
        $file_txt = json_decode($data, true);
    }
}

foreach($conf as $ligne){  // parcours du fichier de conf
   if (strpos($ligne,$file_txt["code"])!==false) {
      $data_conf= explode(",",$ligne);
   }
}

$taille_tab_stats=count($file_tableau['stats']); // on cherche la taille du tableau de stats
$sous_tab_stats=$file_tableau['stats']; // on ouvre le sous tableau de stats


$sous_tab_comm=$file_comm['meilleurs']; // on ouvre le sous tableau de meilleurs
$meilleur_1=$sous_tab_comm[0]; // meilleur commercial
$meilleur_2=$sous_tab_comm[1]; // 2ème meilleur commercial
$meilleur_3=$sous_tab_comm[2]; // 3ème meilleur commercial

$tab_all_txt=array();
$t=$file_txt['titres'];

foreach ($t as $key => $value) {
   array_push($tab_all_txt,$key);
}
$t=$file_txt['sous_titres'];
foreach ($t as $key => $value) {
   array_push($tab_all_txt,$key);
}
$t=$file_txt['textes'];
foreach ($t as $key => $value) {
   array_push($tab_all_txt,$key);
}

$taille_tab_all_txt=count($tab_all_txt);//on cherche la taille du tableau et on le trie
for ($i=0; $i <$taille_tab_all_txt ; $i++) { 
   for ($j=$i; $j <$taille_tab_all_txt-1 ; $j++) { 
      if ($tab_all_txt[$j]>$tab_all_txt[$j+1]) {
         $tempo=$tab_all_txt[$j];
         $tab_all_txt[$j]=$tab_all_txt[$j+1];
         $tab_all_txt[$j+1]=$tempo;
      }
   }
}

$tab_type_txt=array();
foreach ($file_txt['titres'] as $key => $value) {
   foreach ($tab_all_txt as $clé => $numligne) {
      if ($numligne==$key) {
         $tab_type_txt[$clé]='titres';
      }
   }
}
foreach ($file_txt['sous_titres'] as $key => $value) {
   foreach ($tab_all_txt as $clé => $numligne) {
      if ($numligne==$key) {
         $tab_type_txt[$clé]='sous_titres';
      }
   }
}
foreach ($file_txt['textes'] as $key => $value) {
   foreach ($tab_all_txt as $clé => $numligne) {
      if ($numligne==$key) {
         $tab_type_txt[$clé]='textes';
      }
   }
}

?>
<!DOCTYPE html>
<html lang="fr">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>PDF</title>
   <link rel="stylesheet" href="pdf.css">
</head>

<body>
   <section id="couverture">
      <div id="couverture-title">
         <h1>Big Brain</h1>
      </div>
      <div id="couverture-subtitle">
         <h2><span>Région :</span><?php echo $data_conf[1]?></h2>
         <h2><span>Population :</span> <?php echo $data_conf[2]?> habitants</h2>
         <h2><span>Superficie :</span> <?php echo $data_conf[3]?>km²</h2>
         <h2><span>Nombres de départements</span> : <?php echo $data_conf[4]?></h2>
      </div>
      <div id="couverture-image">
         <img src="./workdirs/logos/<?php echo $data_conf[0]?>.png">
      </div>
      <div class="bottom">
         <p>Généré le <?php echo $date?></p>
      </div>
   </section>
   <section>
      <div class="page-header">
         <h1>Résultats trimestriels du <?php echo $date_trimestre?></h1>
      </div>
      <div id="texte-client">
         <?php
         for ($i=0; $i <$taille_tab_all_txt ; $i++) { 
            if ($tab_type_txt[$i]=='titres') {
               $t=$file_txt['titres'];
               ?>
               <h2><?php echo $t[$tab_all_txt[$i]]?></h2>
            <?php
            }
            elseif ($tab_type_txt[$i]=='sous_titres') {
               $t=$file_txt['sous_titres'];
               ?>
               <h3><?php echo $t[$tab_all_txt[$i]]?></h3>
            <?php
            }
            elseif ($tab_type_txt[$i]=='textes') {
               $t=$file_txt['textes'];
               $tab_de_txt=$t[$tab_all_txt[$i]];
               foreach ($tab_de_txt as $key => $value) {
                  ?>
                 <p><?php echo $value?></p>
                 <?php
               }
            }
         }
         ?>
      </div>
      <div id="tableau-page-1">
         <table>
            <caption>Résultats</caption>
            <thead>
               <tr>
                  <th>Numéro du produit</th>
                  <th>Ventes du trimestre</th>
                  <th>Chiffre d’affaires du trimestre</th>
                  <th>Ventes du même trimestre année précédente</th>
                  <th>CA du même trimestre année précédente</th>
                  <th>Evolution du CA en %age</th>
                  <th>Evolution du CA en VA</th>
               </tr>
            </thead>
            <tbody>
            <?php for ($i=0; $i < $taille_tab_stats ; $i++) { 
                        $les_stats=$sous_tab_stats[$i];
                     ?><tr>
                           <td><?php echo $les_stats['product_number']?></td>
                           <td><?php echo $les_stats['ventes_trimestre']?></td>
                           <td><?php echo $les_stats['ca_trimestre']?></td>
                           <td><?php echo $les_stats['ventes_trimestre_precedent']?></td>
                           <td><?php echo $les_stats['ca_trimestre_precedent']?></td>
                           <?php if ($les_stats['evolution_ca_pourcentage']<0){
                              ?>
                              <td style='color:red;'><?php echo $les_stats['evolution_ca_pourcentage']?></td>
                              <?php } else{
                                 ?> 
                                 <td style='color:green;'><?php echo $les_stats['evolution_ca_pourcentage']?></td>
                                 <?php  
                           }
                           if ($les_stats['evolution_ca_pourcentage']<0){
                              ?>
                              <td style='color:red;'><?php echo $les_stats['evolution_ca_va']?></td>
                              <?php } else{
                                 ?> 
                                 <td style='color:green;'><?php echo $les_stats['evolution_ca_va']?></td>
                                 <?php  
                           }
                           ?>
                           
                     </tr>
                     <?php
                     }?>
            </tbody>
         </table>
      </div>
      <div class="bottom">
         <p>Généré le <?php echo $date?></p>
      </div>
   </section>
   <section>
      <div class="page-header">
         <h1>Nos meilleurs vendeurs du trimestre</h1>
      </div>
      <div id="page-2-avatars">
         <div id="commercial-1" class="commercial">
            <img src="./workdirs/photos_converted/<?php echo $meilleur_1['nickname']?>.png">
            <p class="nom"><?php echo $meilleur_1['firstname'].' '.$meilleur_1['lastname']?></p>
            <p>CA : <?php echo $meilleur_1['ca']?>K€</p>
         </div>
         <div id="commercial-2" class="commercial">
            <img src="./workdirs/photos_converted/<?php echo $meilleur_2['nickname']?>.png">
            <p class="nom"><?php echo $meilleur_2['firstname'].' '.$meilleur_2['lastname']?></p>
            <p>CA : <?php echo $meilleur_2['ca']?>K€</p>
         </div>
         <div id="commercial-3" class="commercial">
            <img src="./workdirs/photos_converted/<?php echo $meilleur_3['nickname']?>.png">
            <p class="nom"><?php echo $meilleur_3['firstname'].' '.$meilleur_3['lastname']?></p>
            <p>CA : <?php echo $meilleur_3['ca']?>K€</p>
         </div>
      </div>
      <div class="bottom">
         <p>Généré le <?php echo $date?></p>
      </div>
   </section>
   <section>
      <div class="page-header">
         <h1>Lien vers la page de la région</h1>
      </div>
      <div id="region-link">
         <a href="https://bigbrain.biz/<?php echo $data_conf[0]?>">Lien vers la page de la région</a>
      </div>
      <div id="region-qrcode">
         <img src="./workdirs/qrcode-workdir/qrcodes/<?php echo $data_conf[0]?>.png">
      </div>
      <div class="bottom">
         <p>Généré le <?php echo $date?></p>
      </div>
   </section>
</body>

</html>