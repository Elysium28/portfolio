$directory='workdirs/texte-workdir/textes';
$tabdir=scandir($directory,SCANDIR_SORT_ASCENDING);

foreach ($tabdir as $key => $value) {
    
}